<!DOCTYPE html>
<html style="font-size: 16px;" lang="en"><head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="utf-8">
    <meta name="keywords" content="​GROW&nbsp; YOUR 
BUSINESS&nbsp; WITH 
ANNCAR, PAGE&nbsp;TITLE">
    <meta name="description" content="">
    <title>Home</title>
    <link rel="stylesheet" href="nicepage.css" media="screen">
<link rel="stylesheet" href="Home.css" media="screen">
    <script class="u-script" type="text/javascript" src="jquery.js" defer=""></script>
    <script class="u-script" type="text/javascript" src="nicepage.js" defer=""></script>
    <meta name="generator" content="Nicepage 5.18.6, nicepage.com">
    <link id="u-theme-google-font" rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i|Open+Sans:300,300i,400,400i,500,500i,600,600i,700,700i,800,800i">
    
    
    
    
    
    <script type="application/ld+json">{
		"@context": "http://schema.org",
		"@type": "Organization",
		"name": "",
		"logo": "images/logo.png"
}</script>
    <meta name="theme-color" content="#478ac9">
    <meta property="og:title" content="Home">
    <meta property="og:type" content="website">
  <meta data-intl-tel-input-cdn-path="intlTelInput/"></head>
  <body data-home-page="Home.html" data-home-page-title="Home" data-path-to-root="./" class="u-body u-xl-mode" data-lang="en"><header class=" u-border-no-bottom u-border-no-left u-border-no-right u-border-no-top u-clearfix u-header u-section-row-container" id="sec-ae67" style=""><div class="u-section-rows">
        <div class="u-clearfix u-custom-color-1 u-section-row" data-animation-name="" data-animation-duration="0" data-animation-delay="0" data-animation-direction="">
          <div class="u-clearfix u-sheet u-sheet-1">
            <div class="u-border-3 u-border-white u-line u-line-vertical u-line-1"></div>
            <p class="u-text u-text-default u-text-1"> sales@anncarequipment.com</p>
            <p class="u-align-left u-text u-text-default u-text-2"> 786-842-0320</p>
            <img class="u-image u-image-contain u-image-default u-preserve-proportions u-image-1" src="images/mail.png" alt="" data-image-width="150" data-image-height="109">
            <img class="u-image u-image-contain u-image-default u-preserve-proportions u-image-2" src="images/telephone-call1.png" alt="" data-image-width="150" data-image-height="150">
          </div>
          
          
          
          
          
        </div>
        <div class="u-section-row">
          <div class="u-clearfix u-sheet u-sheet-2">
            <nav class="u-menu u-menu-dropdown u-offcanvas u-menu-1">
              <div class="menu-collapse" style="font-size: 0.875rem; letter-spacing: 0px; font-weight: 700;">
                <a class="u-button-style u-custom-border u-custom-border-color u-custom-borders u-custom-left-right-menu-spacing u-custom-padding-bottom u-custom-text-color u-custom-top-bottom-menu-spacing u-nav-link u-text-active-palette-1-base u-text-hover-palette-2-base" href="#">
                  <svg class="u-svg-link" viewBox="0 0 24 24"><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#menu-hamburger"></use></svg>
                  <svg class="u-svg-content" version="1.1" id="menu-hamburger" viewBox="0 0 16 16" x="0px" y="0px" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg"><g><rect y="1" width="16" height="2"></rect><rect y="7" width="16" height="2"></rect><rect y="13" width="16" height="2"></rect>
</g></svg>
                </a>
              </div>
              <div class="u-custom-menu u-nav-container">
                <ul class="u-nav u-spacing-20 u-unstyled u-nav-1"><li class="u-nav-item"><a class="u-border-no-bottom u-border-no-left u-border-no-right u-border-no-top u-button-style u-nav-link u-text-active-palette-1-base u-text-grey-90 u-text-hover-palette-2-base" href="Home.html" style="padding: 10px;">HOME</a>
</li><li class="u-nav-item"><a class="u-border-no-bottom u-border-no-left u-border-no-right u-border-no-top u-button-style u-nav-link u-text-active-palette-1-base u-text-grey-90 u-text-hover-palette-2-base" href="About.html" style="padding: 10px;">ABOUT</a>
</li><li class="u-nav-item"><a class="u-border-no-bottom u-border-no-left u-border-no-right u-border-no-top u-button-style u-nav-link u-text-active-palette-1-base u-text-grey-90 u-text-hover-palette-2-base" style="padding: 10px;">BRANDS</a>
</li><li class="u-nav-item"><a class="u-border-no-bottom u-border-no-left u-border-no-right u-border-no-top u-button-style u-nav-link u-text-active-palette-1-base u-text-grey-90 u-text-hover-palette-2-base" style="padding: 10px;">PARTS</a>
</li><li class="u-nav-item"><a class="u-border-no-bottom u-border-no-left u-border-no-right u-border-no-top u-button-style u-nav-link u-text-active-palette-1-base u-text-grey-90 u-text-hover-palette-2-base" style="padding: 10px;">EQUIPMENTS</a>
</li><li class="u-nav-item"><a class="u-border-no-bottom u-border-no-left u-border-no-right u-border-no-top u-button-style u-nav-link u-text-active-palette-1-base u-text-grey-90 u-text-hover-palette-2-base" style="padding: 10px;">CONTACT</a>
</li></ul>
              </div>
              <div class="u-custom-menu u-nav-container-collapse">
                <div class="u-black u-container-style u-inner-container-layout u-opacity u-opacity-95 u-sidenav">
                  <div class="u-inner-container-layout u-sidenav-overflow">
                    <div class="u-menu-close"></div>
                    <ul class="u-align-center u-nav u-popupmenu-items u-unstyled u-nav-2"><li class="u-nav-item"><a class="u-button-style u-nav-link" href="Home.html">HOME</a>
</li><li class="u-nav-item"><a class="u-button-style u-nav-link" href="About.html">ABOUT</a>
</li><li class="u-nav-item"><a class="u-button-style u-nav-link">BRANDS</a>
</li><li class="u-nav-item"><a class="u-button-style u-nav-link">PARTS</a>
</li><li class="u-nav-item"><a class="u-button-style u-nav-link">EQUIPMENTS</a>
</li><li class="u-nav-item"><a class="u-button-style u-nav-link">CONTACT</a>
</li></ul>
                  </div>
                </div>
                <div class="u-black u-menu-overlay u-opacity u-opacity-70"></div>
              </div>
            </nav>
            <a href="https://nicepage.me" class="u-image u-logo u-image-3" data-image-width="137" data-image-height="70">
              <img src="images/logo.png" class="u-logo-image u-logo-image-1">
            </a>
            <a href="https://nicepage.com/c/pricing-html-templates" class="u-border-none u-btn u-btn-round u-button-style u-gradient u-hover-feature u-hover-palette-1-light-1 u-none u-radius-50 u-text-body-alt-color u-btn-1">Need Estimate?</a>
            <img class="u-image u-image-contain u-image-default u-preserve-proportions u-image-4" src="images/calculator.png" alt="" data-image-width="22" data-image-height="22">
          </div>
          
          
          
          
          
        </div>
      </div></header>